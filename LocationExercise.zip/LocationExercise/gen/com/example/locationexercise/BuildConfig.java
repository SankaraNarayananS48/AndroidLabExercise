/** Automatically generated file. DO NOT MODIFY */
package com.example.locationexercise;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}